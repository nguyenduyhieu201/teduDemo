using AutoMapper;
using System.Collections.Generic;
using System.Net;
using System.Net.Http;
using quanLyBanHang.Model.Models;
using quanLyBanHang.Service;
using quanLyBanHang.Model.Dto;
using quanLyBanHang.Web.Infrastructure.Extensions;
using quanLyBanHang.WebCore.Infrastructure.Core;
using Microsoft.AspNetCore.Mvc;

namespace quanLyBanHang.Web.Api
{
    [ApiController]
    [Route("[controller]")]
    public class PostCategoryController : ApiControllerBase
    {
        private IPostCategoryService _postCategoryService;
        private readonly IMapper _mapper;
        public PostCategoryController(IErrorService errorService, IPostCategoryService postCategoryService,
            IMapper mapper) : base(errorService)
        {
            _postCategoryService = postCategoryService;
            _mapper = mapper;
        }

        [Route("getall")]
        public HttpResponseMessage Get([FromBody] HttpRequestMessage request)
        {
            return CreateHttpResponse(request, () =>
            {
                var listCategory = _postCategoryService.GetAll();

                var listPostCategoryVm = _mapper.Map<List<PostCategoryViewModel>>(listCategory);

                HttpResponseMessage response = request.CreateResponse(HttpStatusCode.OK, listPostCategoryVm);

                return response;
            });
        }

        [Route("add")]
        public HttpResponseMessage Post([FromQuery] HttpRequestMessage request,[FromBody] PostCategoryViewModel postCategoryVm)
        {
            return CreateHttpResponse(request, () =>
            {
                HttpResponseMessage response = null;
                if (ModelState.IsValid)
                {
                    request.CreateErrorResponse(HttpStatusCode.BadRequest, "create da bi loi");
                }
                else
                {
                    PostCategory newPostCategory = new PostCategory();
                    newPostCategory.UpdatePostCategory(postCategoryVm);

                    var category = _postCategoryService.Add(newPostCategory);
                    _postCategoryService.Save();

                    response = request.CreateResponse(HttpStatusCode.Created, category);

                }
                return response;
            });
        }

        // [Route("update")]
        // public HttpResponseMessage Put(HttpRequestMessage request, PostCategoryViewModel postCategoryVm)
        // {
        //     return CreateHttpResponse(request, () =>
        //     {
        //         HttpResponseMessage response = null;
        //         if (ModelState.IsValid)
        //         {
        //             request.CreateErrorResponse(HttpStatusCode.BadRequest, "update da bi loi");
        //         }
        //         else
        //         {
        //             var postCategoryDb = _postCategoryService.GetById(postCategoryVm.ID);
        //             postCategoryDb.UpdatePostCategory(postCategoryVm);
        //             _postCategoryService.Update(postCategoryDb);
        //             _postCategoryService.Save();

        //             response = request.CreateResponse(HttpStatusCode.OK);

        //         }
        //         return response;
        //     });
        // }

        // [Route("delete")]

        // public HttpResponseMessage Delete(HttpRequestMessage request, int id)
        // {
        //     return CreateHttpResponse(request, () =>
        //     {
        //         HttpResponseMessage response = null;
        //         if (ModelState.IsValid)
        //         {
        //             request.CreateErrorResponse(HttpStatusCode.BadRequest, "Delete da bi loi");
        //         }
        //         else
        //         {
        //             _postCategoryService.Delete(id);
        //             _postCategoryService.Save();

        //             response = request.CreateResponse(HttpStatusCode.OK);
        //         }
        //         return response;
        //     });
        // }
    }
}
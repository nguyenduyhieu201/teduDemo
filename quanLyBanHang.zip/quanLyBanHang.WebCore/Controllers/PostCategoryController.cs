﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace quanLyBanHang.WebCore.Controllers
{
    public class PostCategoryController
    {
    }
}

﻿using System;

namespace quanLyBanHang.Common
{
    public class Class1
    {
    }
}
